package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.concurrent.Callable;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // We made variables jiski humko jarrorat thi
        TextView txtResult;
        EditText edtWeight,edtHeightFt,edtHeightIn;
        Button Calculate;

        // Now we have to assign these variables
        edtWeight = findViewById(R.id.EtWeight);
        edtHeightFt = findViewById(R.id.EtHeight);
        edtHeightIn = findViewById(R.id.EtHeightIn);
        Calculate = findViewById(R.id.btnCalculate);
        txtResult = findViewById(R.id.TxtResult);
        LinearLayout llmain;
        llmain = findViewById(R.id.llMain);

         // We have to make a on click for a button so that action is performed whenever button is clicked

        // We took the object of on click listener by new keyword and on click listener is not directly got because we are setting on click listener for a button and it comes under view class(button is derived from view class)
        Calculate.setOnClickListener(new View.OnClickListener() {
            @Override // Override method onClick class is got by ONclickListener above
            public void onClick(View view) {
                int wt = Integer.parseInt(edtWeight.getText().toString());  // First edtWeight text got by get text and converted to string and then it is converted to integer by Integer.parseINt
                int ft = Integer.parseInt(edtHeightFt.getText().toString());
                int in = Integer.parseInt(edtHeightIn.getText().toString());

                int totalIn = ft * 12 + in;
                double totalCm = totalIn * 2.53;
                double totalM = totalCm / 100;
                double bmi = wt / (totalM * totalM);

                if(bmi>25)
                {
                    txtResult.setText("You are Overweight !");
                    llmain.setBackgroundColor(getResources().getColor(R.color.Ow));
                }
                else if(bmi<18)
                {
                    txtResult.setText("You are Underweight !");
                    llmain.setBackgroundColor(getResources().getColor(R.color.Uw));
                }
                else
                {txtResult.setText("You are Healthy !");
                    llmain.setBackgroundColor(getResources().getColor(R.color.H));
                }

            }
        });

    }
}